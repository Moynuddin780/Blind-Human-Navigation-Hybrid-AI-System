import cv2
import os

def collect_images(class_name, save_dir="data/raw", num_images=100):
    """
    Capture images from webcam for a specific class
    """
    class_path = os.path.join(save_dir, class_name)
    os.makedirs(class_path, exist_ok=True)

    cap = cv2.VideoCapture(0)
    count = 0
    print(f"Collecting images for class: {class_name}")

    while count < num_images:
        ret, frame = cap.read()
        if not ret:
            continue

        cv2.imshow(f"Collecting {class_name}", frame)
        key = cv2.waitKey(1) & 0xFF

        # Press 'c' to capture
        if key == ord('c'):
            img_path = os.path.join(class_path, f"{count:04d}.jpg")
            cv2.imwrite(img_path, frame)
            print(f"Saved: {img_path}")
            count += 1

        # Press 'q' to quit
        if key == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print(f"Finished collecting {count} images for {class_name}")

# Test
if __name__ == "__main__":
    collect_images("road", num_images=50)
