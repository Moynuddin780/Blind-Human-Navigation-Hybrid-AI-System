import os
import subprocess

def open_labelimg(image_dir="data/raw"):
    """
    Opens LabelImg for manual annotation
    """
    # Assuming LabelImg is installed and in PATH
    try:
        subprocess.call(["labelImg", image_dir])
    except FileNotFoundError:
        print("LabelImg not found. Please install it and add to PATH.")

def open_roboflow_export(export_path="data/raw"):
    """
    Placeholder for any Roboflow automation (optional)
    """
    print(f"Open Roboflow export folder: {export_path}")
    os.startfile(export_path)  # Windows only

# Test
if __name__ == "__main__":
    open_labelimg("data/raw/road")
