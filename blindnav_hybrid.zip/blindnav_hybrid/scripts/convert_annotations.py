import os
import json
import xml.etree.ElementTree as ET

def voc_to_yolo(voc_xml_path, class_map, img_width, img_height):
    """
    Convert single VOC XML file to YOLO .txt format
    class_map: dict {class_name: class_id}
    """
    tree = ET.parse(voc_xml_path)
    root = tree.getroot()
    yolo_lines = []

    for obj in root.findall("object"):
        class_name = obj.find("name").text
        if class_name not in class_map:
            continue
        cls_id = class_map[class_name]
        bbox = obj.find("bndbox")
        x_min = float(bbox.find("xmin").text)
        y_min = float(bbox.find("ymin").text)
        x_max = float(bbox.find("xmax").text)
        y_max = float(bbox.find("ymax").text)

        # Convert to YOLO format
        x_center = ((x_min + x_max)/2) / img_width
        y_center = ((y_min + y_max)/2) / img_height
        w = (x_max - x_min) / img_width
        h = (y_max - y_min) / img_height

        yolo_lines.append(f"{cls_id} {x_center} {y_center} {w} {h}")

    return "\n".join(yolo_lines)

def save_yolo_txt(yolo_str, save_path):
    with open(save_path, "w") as f:
        f.write(yolo_str)

# Example usage
if __name__ == "__main__":
    class_map = {"road":0, "pothole":1, "stairs":2}
    txt = voc_to_yolo("data/annotations/sample.xml", class_map, img_width=640, img_height=480)
    save_yolo_txt(txt, "data/labels/sample.txt")
    print("Conversion done!")
