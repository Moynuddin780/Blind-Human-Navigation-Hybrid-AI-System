from ultralytics import YOLO

# Training custom YOLO model on your dataset
def train_custom_model(data_yaml="data.yaml", pretrained="models/pretrained/yolov8n.pt",
                       epochs=50, batch=8, img_size=640, save_path="models/custom/"):
    model = YOLO(pretrained)
    model.train(
        data=data_yaml,
        epochs=epochs,
        batch=batch,
        imgsz=img_size,
        project=save_path,
        name="custom_train",
        exist_ok=True
    )
    print("Training finished! Best weights saved in:", save_path)

if __name__ == "__main__":
    train_custom_model()
