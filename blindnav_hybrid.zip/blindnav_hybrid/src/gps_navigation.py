from geopy.distance import geodesic

class GPSNavigation:
    """
    Simple GPS navigation wrapper
    """
    def __init__(self, route_points):
        """
        route_points: list of (lat, lon) tuples for path
        """
        self.route = route_points
        self.current_index = 0

    def get_next_instruction(self, current_location):
        """
        current_location: (lat, lon)
        returns: (instruction_text, distance_to_next_point)
        """
        if self.current_index >= len(self.route):
            return ("You have reached your destination", 0)

        next_point = self.route[self.current_index]
        distance = geodesic(current_location, next_point).meters

        if distance < 3:  # Reached point, move to next
            self.current_index += 1
            return self.get_next_instruction(current_location)

        # Simple instruction (placeholder)
        return ("Move towards next point", distance)

# Test
if __name__ == "__main__":
    gps = GPSNavigation([(23.8103,90.4125),(23.8110,90.4130)])
    current_loc = (23.8103, 90.4125)
    print(gps.get_next_instruction(current_loc))
