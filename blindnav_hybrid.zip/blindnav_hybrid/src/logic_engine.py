import math

class LogicEngine:
    """
    Converts object detection + depth + GPS info to guidance
    """
    def __init__(self, tts=None):
        self.tts = tts

    def generate_guidance(self, detections, depth_map, gps_instruction=None):
        """
        detections: list of {"bbox":[x1,y1,x2,y2], "conf":0.5, "class_id":1}
        depth_map: normalized 0-1 depth array
        gps_instruction: string from GPSNavigation
        """
        messages = []

        # Check for obstacles
        for det in detections:
            cls = det["class_id"]
            conf = det["conf"]
            if conf < 0.4:
                continue
            # Example: obstacle
            if cls in [0,1,2,3,4,5]:  # custom class IDs placeholder
                messages.append(f"Obstacle detected ahead: class {cls}")

        # Include GPS instruction
        if gps_instruction:
            messages.append(gps_instruction)

        # Speak messages
        if self.tts:
            for msg in messages:
                self.tts.speak(msg)

        return messages

# Test
if __name__ == "__main__":
    from text_to_speech import TextToSpeech
    tts = TextToSpeech()
    engine = LogicEngine(tts=tts)
    sample_dets = [{"bbox":[0,0,10,10], "conf":0.9, "class_id":0}]
    engine.generate_guidance(sample_dets, None, gps_instruction="Move forward")
