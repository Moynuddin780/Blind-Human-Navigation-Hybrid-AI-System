import cv2
import numpy as np

def show_depth(depth_map):
    """
    Show depth map as heatmap
    """
    depth_color = cv2.applyColorMap((depth_map*255).astype(np.uint8), cv2.COLORMAP_JET)
    cv2.imshow("Depth Map", depth_color)

def show_frame_with_boxes(frame, detections, class_names=None):
    from utils import draw_boxes
    frame = draw_boxes(frame, detections, class_names)
    cv2.imshow("Detection", cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
