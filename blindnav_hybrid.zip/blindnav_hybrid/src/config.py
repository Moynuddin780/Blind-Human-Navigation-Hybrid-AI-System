# Global config and hyperparameters

# Paths
DATA_DIR = "./data"
PRETRAINED_WEIGHTS = "./models/pretrained/yolov8n.pt"
CUSTOM_WEIGHTS = "./models/custom/best_custom.pt"

# YOLO params
IMG_SIZE = 640
CONF_THRESH = 0.35
IOU_THRESH = 0.45

# Classes
CUSTOM_CLASSES = [
    "road",
    "footpath",
    "pothole",
    "wet_floor",
    "broken_road",
    "stairs",
    "bricks",
    "obstacles",
    "construction",
    "signboard"
]

COCO_USE = True  # Use COCO pretrained classes
