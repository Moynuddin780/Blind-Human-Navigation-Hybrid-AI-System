from ultralytics import YOLO
import cv2

class ObjectDetector:
    def __init__(self, pretrained_weights="models/pretrained/yolov8n.pt", conf_thresh=0.35):
        self.model = YOLO(pretrained_weights)
        self.conf_thresh = conf_thresh

    def detect(self, frame):
        # frame: RGB image
        results = self.model.predict(frame, conf=self.conf_thresh, verbose=False)
        detections = []
        for r in results:
            if r.boxes is not None:
                for i in range(len(r.boxes)):
                    x1, y1, x2, y2 = r.boxes.xyxy[i].tolist()
                    conf = r.boxes.conf[i].item()
                    cls_id = int(r.boxes.cls[i].item())
                    detections.append({
                        "bbox": [x1, y1, x2, y2],
                        "conf": conf,
                        "class_id": cls_id
                    })
        return detections

# Test code
if __name__ == "__main__":
    from camera_stream import CameraStream
    cam = CameraStream()
    detector = ObjectDetector()
    while True:
        frame = cam.read()
        dets = detector.detect(frame)
        for d in dets:
            x1, y1, x2, y2 = map(int, d["bbox"])
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0,255,0), 2)
        cv2.imshow("Detection", cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cam.release()
