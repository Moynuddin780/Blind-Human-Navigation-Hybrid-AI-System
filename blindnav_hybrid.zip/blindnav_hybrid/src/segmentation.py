import cv2
import numpy as np

class RoadSegmentation:
    """
    Basic color-based segmentation for walkable areas.
    This is a placeholder; for real deployment, use deep learning segmentation models.
    """
    def __init__(self):
        pass

    def segment(self, frame):
        """
        Returns a mask where road/walkable area is 1, others 0
        """
        hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV)

        # Example: detect gray/road color
        lower = np.array([0, 0, 50])
        upper = np.array([180, 50, 200])
        mask = cv2.inRange(hsv, lower, upper)
        mask = mask // 255  # Convert to 0/1
        return mask

# Test code
if __name__ == "__main__":
    from camera_stream import CameraStream
    cam = CameraStream()
    seg = RoadSegmentation()
    while True:
        frame = cam.read()
        mask = seg.segment(frame)
        cv2.imshow("Mask", mask*255)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cam.release()
