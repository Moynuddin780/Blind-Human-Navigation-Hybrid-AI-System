import cv2
import os
import numpy as np

def draw_boxes(frame, detections, class_names=None):
    """
    Draw bounding boxes on frame
    """
    for det in detections:
        x1, y1, x2, y2 = map(int, det["bbox"])
        cls_id = det["class_id"]
        label = str(cls_id) if not class_names else class_names[cls_id]
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0,255,0), 2)
        cv2.putText(frame, label, (x1, y1-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
    return frame

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def normalize_depth(depth_map):
    """
    Normalize depth map 0-1
    """
    min_val = np.min(depth_map)
    max_val = np.max(depth_map)
    return (depth_map - min_val) / (max_val - min_val + 1e-8)
