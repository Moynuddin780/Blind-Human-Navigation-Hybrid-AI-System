import cv2
import torch
import numpy as np
from PIL import Image

# Using MiDaS small model for depth estimation
class DepthEstimator:
    def __init__(self, model_type="DPT_Small"):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = torch.hub.load("intel-isl/MiDaS", model_type)
        self.model.to(self.device)
        self.model.eval()
        self.transform = torch.hub.load("intel-isl/MiDaS", "transforms").small_transform if model_type=="DPT_Small" else torch.hub.load("intel-isl/MiDaS", "transforms").dpt_transform

    def estimate(self, frame):
        img = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        img = Image.fromarray(img)
        input_batch = self.transform(img).to(self.device)
        with torch.no_grad():
            prediction = self.model(input_batch)
            prediction = torch.nn.functional.interpolate(
                prediction.unsqueeze(1),
                size=frame.shape[:2],
                mode="bilinear",
                align_corners=False
            ).squeeze().cpu().numpy()
        # Normalize depth map 0-1
        depth_min, depth_max = prediction.min(), prediction.max()
        depth_norm = (prediction - depth_min) / (depth_max - depth_min + 1e-8)
        return depth_norm

# Test code
if __name__ == "__main__":
    from camera_stream import CameraStream
    cam = CameraStream()
    depth_estimator = DepthEstimator()
    while True:
        frame = cam.read()
        depth_map = depth_estimator.estimate(frame)
        cv2.imshow("Depth", depth_map)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cam.release()
