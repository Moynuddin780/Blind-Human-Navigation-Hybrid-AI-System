import vosk
import sys
import sounddevice as sd
import queue
import json

class SpeechToText:
    def __init__(self, model_path="models/asr/vosk-model-small-en-us-0.15"):
        self.q = queue.Queue()
        self.model = vosk.Model(model_path)
        self.rec = vosk.KaldiRecognizer(self.model, 16000)

    def callback(self, indata, frames, time, status):
        self.q.put(bytes(indata))

    def listen(self, duration=5):
        import sounddevice as sd
        with sd.InputStream(channels=1, samplerate=16000, callback=self.callback):
            result = None
            while True:
                data = self.q.get()
                if self.rec.AcceptWaveform(data):
                    result = json.loads(self.rec.Result())
                    break
            return result.get("text", "")

# Test
if __name__ == "__main__":
    stt = SpeechToText()
    print("Say something...")
    text = stt.listen()
    print("You said:", text)
