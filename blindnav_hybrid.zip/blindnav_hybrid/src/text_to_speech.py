import pyttsx3

class TextToSpeech:
    def __init__(self, rate=150, volume=1.0):
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', rate)
        self.engine.setProperty('volume', volume)

    def speak(self, text):
        self.engine.say(text)
        self.engine.runAndWait()

# Test
if __name__ == "__main__":
    tts = TextToSpeech()
    tts.speak("Hello! This is Blind Navigation test.")
